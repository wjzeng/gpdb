# -*- coding: utf-8 -*-
"""
Used for behave as compatibility layer between different Python versions
and implementations.
"""
