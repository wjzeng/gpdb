.. _id.appendix.related:

===============================
Software that Enhances *behave*
===============================

* Mock
* nose.tools and nose.twistedtools
* mechanize for pretending to be a browser
* selenium webdriver for actually driving a browser
* wsgi_intercept for providing more easily testable WSGI servers
* BeautifulSoup, lxml and html5lib for parsing HTML
* ...

